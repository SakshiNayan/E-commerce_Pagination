import ProductPg from "./Component/productPg";


function App() {
  return (
    <div className="App">
      <ProductPg/>
    </div>
  );
}

export default App;
